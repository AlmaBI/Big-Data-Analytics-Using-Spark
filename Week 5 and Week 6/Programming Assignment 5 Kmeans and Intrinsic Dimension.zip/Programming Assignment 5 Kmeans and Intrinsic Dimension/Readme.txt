Programming Assignments due Mar 9, 2021 19:00 CET
Programming Assignment 5: K-means and Intrinsic Dimension
In this programming assignment, you will write pyspark code to estimate the intrinsic dimension of a dataset using K-means clustering.

Given a sample set of a synthetically generated dataset, you will use the Spark K-means API to estimate the centroids of the data points. After obtaining the centroids of the data, you will calculate the mean-squared error of the dataset by calculating the mean-squared distance of each datapoint from it's respective representative centroid. This experiment is to be repeated for different values of K (K being the number of centroids), for the same sample of data. Using the information obtained from these experiments, you can estimate the intrinsic dimension of the sample set.

You are expected to repeat the above procedure for sample sets of different sizes and thereby estimate the intrinsic dimension of each sample set. 

For Audit Learners
To download the tar file for PA5 click here.

After Downloading the file, "cd" to the download directory and unpack it using the command: "tar -xzf pa5.tar"

You should get a directory named pa5 which contains the jupyter notebook for Programming Assignment 5. 

Depending on your installation setup, you could either mount the directory on docker (if you are using docker) OR just run jupyter locally and start working on the assignment. We do not currently support submission and grading of assignments for audit learners. However, the assignment notebook contains the necessary information that you can use to verify the correctness of your code.